class BossRoom extends Room {
    Enemy boss;
    Weapon reward;
    @Override
    public void attackChain() {}
}