class Weapon {
    String weaponName;
    String damageType;
    public Weapon(String w, String n) {
        this.weaponName = w;
        this.damageType = n;
        String article;
        char det = this.weaponName.charAt(0);
        switch(det) {
            case 'a': case 'e': case 'i': case 'o': case 'u': case 'A': case 'E': case 'I': case 'O': case 'U':
                article = "an";
                break;
            default:
                article = "a";
                break;
        }
        System.out.printf("You have acquired a new Weapon. It is %s %s. You can %s Terrors with it.\n\n", article, this.weaponName, this.damageType);
    }
}