class NormalRoom extends Room {
    ArrayList<Enemy> list = new ArrayList();
    @Override
    public void attackChain() {}
}