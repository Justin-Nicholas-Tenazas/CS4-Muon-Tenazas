class Enemy {
    String name;
    int threat;
    boolean designation;
    String damageWeakness;
    ArrayList<String> weakpoints = new ArrayList();
    public void damage(Player p) {
        p.lives--;
    }
}