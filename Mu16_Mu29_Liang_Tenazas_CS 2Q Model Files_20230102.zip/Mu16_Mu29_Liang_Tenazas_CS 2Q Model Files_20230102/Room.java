abstract class Room {
    String name;
    boolean access;
    public abstract void attackChain();
}