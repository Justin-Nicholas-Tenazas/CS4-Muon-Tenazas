class Player {
    String playerName;
    int lives;
    Weapon playerWeapon;
    public void changeWeapon(Weapon weaponOne, Weapon weaponTwo) {
        Scanner cw = new Scanner(System.in);
        String confirmChange;
        System.out.println("Do you wish to equip this Weapon? Note that if you do, it will stay with you through the rest of your journey, and you cannot revert once you have made your choice. [Type Y for Yes or N for No]");
        confirmChange = cw.nextLine();
        if(confirmChange.equalsIgnoreCase("y")) {
            weaponOne.weaponName = weaponTwo.weaponName;
            weaponOne.damageType = weaponTwo.damageType;
            System.out.printf("The %s is now your equipped Weapon.", weaponOne.weaponName);
        }
    }
    public void kill(Enemy e) {
        if(this.playerWeapon.damageType == e.damageWeakness) {}
    }
    public void enterRoom(Room pass) {
        if(pass.access == true) {pass.attackChain();}
    }
}