public class Singer {
    String name;
    int noOfPerformances = 0;
    double earnings = 0;
    Song favoriteSong;
    public void performForAudience(int audienceCount){
        for(int i = 0; i < audienceCount; i++) {
            noOfPerformances++;
            earnings += 100;
            System.out.printf("%s has performed %s %d times and has earned %f PHP.\n", this.name, favoriteSong.songName, noOfPerformances, earnings);
        }
    }
    public void changeFavSong(Song newFav) {
        favoriteSong = newFav;
        System.out.printf("%s's favorite song is now %s.\n", this.name, favoriteSong.songName);
    }
    public Singer(String n) {
        this.name = n;
        System.out.printf("Hello! I am your singer for today! My name is %s! Nice to meet you!\n", this.name);
    }