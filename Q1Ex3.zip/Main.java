public class Main
{
	public static void main(String[] args) {
		Zombie zomDog1 = new Zombie("Zombie Dog", 10, false);
		Zombie licker1 = new Zombie("Licker", 45, true);
		Zombie tyrant1 = new Zombie("Tyrant", 200, true);
		System.out.println("");
		Song songOne = new Song("Left and Right", "Pop", "Charlie Puth ft. Jung Kook");
		Song songTwo = new Song("Switch to Me", "K-Pop", "DubChaeng");
		System.out.println("");
		Singer singerOne = new Singer("Jeon Joo-hyun");
		singerOne.changeFavSong(songOne);
		singerOne.performForAudience(12);
		singerOne.changeFavSong(songTwo);
	}
}