public class Zombie {
    String type;
    int health;
    boolean danger;
    public Zombie(String t, int h, boolean d) {
        this.type = t;
        this.health = h;
        this.danger = d;
        System.out.printf("This is a Zombie. It is a %s. Its health is %d. Is it dangerous? %b. \n", this.type, this.health, this.danger);
    }