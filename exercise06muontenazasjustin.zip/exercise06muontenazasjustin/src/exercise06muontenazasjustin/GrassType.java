/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise06muontenazasjustin;

/**
 *
 * @author MUON
 */
public class GrassType extends Monster {
    @Override
    public void special(){
        hp += 0.2*maxHP;
        System.out.println(name + " increased their HP!");
    }
    
    public GrassType(String n, int h, int a){
        super(n, "grass", "water", "fire", h, a);
    }
    
}