/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise06muontenazasjustin;

/**
 *
 * @author MUON
 */
public class Main {
	public static void main(String[] args) {
		FireType fr = new FireType("Fletchling", 30, 10);
		WaterType wt = new WaterType("Froakie", 30, 10);
		GrassType gr = new GrassType("Rowlet", 30, 10);
		while(gr.getHP() != 0 && fr.getHP() != 0) {
		    gr.attack(fr);
		    fr.attack(gr);
		}
		gr.restoreHealth();
		fr.restoreHealth();
		while(fr.getHP() != 0 && wt.getHP() != 0) {
		    fr.attack(wt);
		    wt.attack(fr);
		}
		fr.restoreHealth();
		wt.restoreHealth();
		while(wt.getHP() != 0 && gr.getHP() != 0) {
		    wt.attack(gr);
		    gr.attack(wt);
		}
		wt.restoreHealth();
		gr.restoreHealth();
	}
}