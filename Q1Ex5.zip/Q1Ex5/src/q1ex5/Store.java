/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1ex5;

/**
 *
 * @author MUON
 */
import java.util.ArrayList;
public class Store {
   private String storeName;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList();

  public Store(String a){
    this.storeName = a;
    this.earnings = 0;
    this.itemList = new ArrayList();
    storeList.add(this);
  }

  public String getName(){
    return storeName;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
    // get Item at index from itemList and add its cost to earnings
    // print statement indicating the sale
    int det = this.itemList.size() - 1;
    if(index < det) {
        this.earnings += this.itemList.get(index).getCost();
        System.out.printf("%s was sold for %f!\n", this.itemList.get(index).getName(), this.itemList.get(index).getCost());
    }
    else{System.out.printf("%s doesn't have that many items! We only have %d items for sale!\n", this.storeName, this.itemList.size());}
  }
  public void sellItem(String givenName){
    // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
    // get Item from itemList and add its cost to earnings
    // print statement indicating the sale
    boolean determinant = false;
    for(Item i : this.itemList){
        if(i.getName().equals(givenName)){
            determinant = true;
            this.earnings += i.getCost();
            System.out.printf("%s was sold for %f!\n", i.getName(), i.getCost());
        }
    }
    if(determinant == false) {System.out.printf("%s doesn't sell that item!\n", this.storeName);}
  }
  public void sellItem(Item i){
    if(this.itemList.contains(i)) {
        this.earnings += i.getCost();
        System.out.printf("%s was sold for %f!\n", i.getName(), i.getCost());
    }
    else{System.out.printf("%s doesn't sell that item!\n", this.storeName);}
  }
  public void addItem(Item i){
    this.itemList.add(i);
  }
  public void filterType(String type){
    // loop over itemList and print all items with the specified type
    System.out.printf("%s Items that are %s-type: \n", this.storeName, type);
    for(Item i : this.itemList){
        if(i.getType().equals(type)){
            System.out.printf("%s\n", i.getName());
        }
    }
    
  }
  public void filterCheap(double maxCost){
    // loop over itemList and print all items with a cost lower than or equal to the specified value
    System.out.printf("%s Items costing less than %f: \n", this.storeName, maxCost);
    for(Item i : this.itemList){
        if(i.getCost() <= maxCost){
            System.out.printf("%s\n", i.getName());
        }
    }
  }
  public void filterExpensive(double minCost){
    // loop over itemList and print all items with a cost higher than or equal to the specified value
    System.out.printf("%s Items costing more than %f: \n", this.storeName, minCost);
    for(Item i : this.itemList){
        if(i.getCost() >= minCost){
            System.out.printf("%s\n", i.getName());
        }
    }
  }
  public static void printStats(){
    // loop over storeList and print the name and the earnings'Store.java'
    System.out.println("Total Earnings");
    storeList.forEach((Store z) -> System.out.printf(" %s: %f\n", z.storeName, z.earnings));
  }
}