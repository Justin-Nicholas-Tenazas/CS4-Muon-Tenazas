/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise07muontenazasjustin;

/**
 *
 * @author MUON
 */
public class WaterType extends Monster {
    @Override
    public void special(){
        def += 2;
        hp -= 0.1*maxHP;
        System.out.printf("%s increased their DEF! Not without the cost of some HP...", this.getName());
    }
    
    public WaterType(String n, int h, int a){
        super(n, "water", "fire", "grass", h, a);
    }
    
}