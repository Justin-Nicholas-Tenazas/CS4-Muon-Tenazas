/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise07muontenazasjustin;

/**
 *
 * @author MUON
 */
public class Main {

    public static void main(String[] args) {
        Monster wt = new WaterType("Primal Kyogre", 100, 100);
        Location complex = new Location("Main Battle Complex", "Cat Jam");
        NPC vendorGuy = new NPC("Vendor Guy", complex);
        Trainer me = new Trainer("Zika", complex);
        me.inspect(wt);
        me.inspect(complex);
        me.inspect(vendorGuy);
    }
    
}
