public class Song {
    String songName;
    int yearRelease;
    String genre;
    int secondsLength;
    String artist;
    String status = "off";
    public void playSong() {status = "on";}
    public void stopSong() {status = "off";}
    public String giveSongName() {return this.songName;}
    public Song(String s, String g, String a) {
        this.songName = s;
        this.genre = g;
        this.artist = a;
        System.out.printf("A new song! This one is %s. It's in the %s genre and is sung by %s.\n", this.songName, this.genre, this.artist);
    }
}