public class Singer {
    private String name;
    private int noOfPerformances = 0;
    private double earnings = 0;
    private static int totalPerformances = 0;
    private Song favoriteSong;
    public int performForAudience(int audienceCount){
        for(int i = 0; i < audienceCount; i++) {
            noOfPerformances++;
            earnings += 100;
            System.out.printf("%s performed %s and has earned %f PHP.\n", this.name, favoriteSong.songName, earnings);
            totalPerformances += 1;
        }
        return totalPerformances;
    }
    public int performForAudience(Singer singer1, Singer singer2, Song song1){
            singer1.noOfPerformances++;
            singer2.noOfPerformances++;
            singer1.earnings += 50;
            singer2.earnings += 50;
            double totalEarnings = singer1.earnings + singer2.earnings;
            System.out.printf("%s and %s have performed %s and earned a total of %f PHP.\n", singer1.name, singer2.name, song1.songName, totalEarnings);
            totalPerformances += 1;
            return totalPerformances;
    }
    public void changeFavSong(Song newFav) {
        favoriteSong = newFav;
        System.out.printf("%s's favorite song is now %s.\n", this.name, favoriteSong.songName);
    }
    public Singer(String n) {
        this.name = n;
        System.out.printf("Hello! I am your singer for today! My name is %s! Nice to meet you!\n", this.name);
    }
}