public class Zombie {
    private String type;
    private int health;
    private boolean danger;
    public Zombie(String t, int h, boolean d) {
        this.type = t;
        this.health = h;
        this.danger = d;
        System.out.printf("This is a Zombie. It is a %s. Its health is %d. Is it dangerous? %b. \n", this.type, this.health, this.danger);
    }
    public int getZombieHealth() {
        System.out.printf("This zombie's health is %d.\n", this.health);
        return this.health;
    }
    public int setZombieHealth(int setH) {
        this.health = setH;
        System.out.printf("At your request, this zombie's health is now %d.\n", this.health);
        return this.health;
    }
}